import React, { Component } from 'react'

export default class RecipeSearch extends Component {
  render() {
    return (
      <React.Fragment>
      <h1>hello from search</h1>
      </React.Fragment>
    )
  }
}
