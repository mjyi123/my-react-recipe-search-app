import React, { Component } from 'react'
import { recipe } from '../tempDetails'

export default class RecipeDetails extends Component {
  render () {
    return (
      <React.Fragment>
        <h1>Hello from details</h1>
      </React.Fragment>
    )
  }
}
